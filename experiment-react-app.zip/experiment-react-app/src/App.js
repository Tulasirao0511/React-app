
import React from 'react';

import './App.css';
import Form from './ValidateForm';

function App() {
  return (
    <div className="App">
      <Form></Form>
    </div>
  );
}

export default App;
